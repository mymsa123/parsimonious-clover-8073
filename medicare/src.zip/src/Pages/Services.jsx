import React from 'react'

export const Services = () => {
  return (
    <div>Service Page</div>
  )
}
