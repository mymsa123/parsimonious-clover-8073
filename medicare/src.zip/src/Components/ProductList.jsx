import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getProduct } from "../Redux/Products/action";
import { ProductCard } from "./ProductCard";
import styled from "styled-components";
import { useSearchParams } from "react-router-dom";

export const ProductList = () => {
  const dispatch = useDispatch();
  const products = useSelector((store) => store.productReducer.products);
  const [searchParams] = useSearchParams()

  const paramsObj = {
    params: {
      Category: searchParams.getAll("Category"),
      _sort: searchParams.get("order") && "Price",
      _order: searchParams.get("order"),
    },
  }; 

  useEffect(() => {
    dispatch(getProduct(paramsObj));
  }, [searchParams]);

  console.log(products);

  return (
    <DIV>
      {products.length > 0 &&
        products.map((el, i) => {
          return <ProductCard key={i} {...el} />;
        })}
    </DIV>
  );
};

const DIV = styled.div`
  display: grid;
  grid-template-columns: auto auto auto;
  gap: 15px;
`;
