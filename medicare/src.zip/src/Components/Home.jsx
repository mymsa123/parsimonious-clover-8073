import medicarelogo from "../assests/medicare11.png"
export const Home = () =>{
    return(
        <div >
            <img src={medicarelogo} width= "100%" />
        </div>
    )
}

