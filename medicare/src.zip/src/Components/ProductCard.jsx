import React from "react";
import { useSelector } from "react-redux";
import { Link } from "react-router-dom";
import styled from "styled-components";

import { useDisclosure } from "@chakra-ui/react";
import { Image, VStack, Text, Button } from "@chakra-ui/react";
import {
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalFooter,
  ModalBody,
  ModalCloseButton,
} from "@chakra-ui/react";

export const ProductCard = ({
  id,
  Name,
  Image,
  Price,
  Desc,
  Category,
  Manufacturer,
}) => {
  const { isOpen, onOpen, onClose } = useDisclosure();

  return (
    <CARDWRAPPER>
      <img src={Image} alt="" width={200} onClick={onOpen} />

      <br />
      <p>{id}</p>
      <h4>{Name}</h4>
      <h4>Price : ₹{Price}</h4>
      <Button onClick={onOpen}>Add to Cart</Button>

      <Modal isOpen={isOpen} onClose={onClose}>
        <ModalOverlay />
        <ModalContent>
          <ModalHeader>{Name}</ModalHeader>
          <ModalCloseButton />
          <ModalBody>
            <VStack>
              <img src={Image} width={100} />
              <Text>Product : {Name}</Text>
              <Text>Brand : {Manufacturer}</Text>
              <Text>Category : {Category}</Text>
              <Text>Price : {Price}</Text>
              <Text>Details: {Desc}</Text>
            </VStack>
          </ModalBody>
          <ModalFooter>
            <Button colorScheme="blue" mr={3} onClick={onClose}>
              Close
            </Button>
          </ModalFooter>
        </ModalContent>
      </Modal>
    </CARDWRAPPER>
  );
};

const CARDWRAPPER = styled.div`
  border: 1px solid gray;
  padding: 10px;
  margin-bottom: 40px;

  img {
    width: 200px;
    border: 1px solid gray;
    border-radius: 5px;
  }

  button {
    width: 90%;
    height: 30px;
    color: white;
    background-color: #00525d;
    border-radius: 5px;
  }
`;

// function ProductItem({
//   id,
//   brand,
//   category,
//   image,
//   price,
//   title
// }) {
//   // // import the chakra UI components from the chakra UI library, and remove the following.
//   // const VStack = () => <div></div>;

//   const { isOpen, onOpen, onClose } =  useDisclosure()
//   return (
//     <VStack
//       data-cy="product-card"
//       spacing="12px"
//       align="center"
//       border="1px solid black"
//       p={4}
//     >
//       <Image src={image} />
//       <Text>Product : {title}</Text>
//       <Text>Brand : {brand}</Text>
//       <Text>Category : {category}</Text>
//       <Text>Price : {price}</Text>
//       <Button onClick={onOpen}>View in Modal</Button>

//       <Modal isOpen={isOpen} onClose={onClose}>
//         <ModalOverlay />
//         <ModalContent>
//           <ModalHeader>Product Name : {title}</ModalHeader>
//           <ModalCloseButton />
//           <ModalBody>
//             <VStack>
//               <Image src={Image} />
//               <Text>Product : {Name}</Text>
//               <Text>Brand : {Manufacturer}</Text>
//               <Text>Category : {Category}</Text>
//               <Text>Price : {price}</Text>
//             </VStack>
//           </ModalBody>
//           <ModalFooter>
//             <Button colorScheme='blue' mr={3} onClick={onClose}>
//               Close
//             </Button>
//           </ModalFooter>
//         </ModalContent>
//       </Modal>
//     </VStack>
//   );
// }

// export default ProductItem;
